// Dummy file. The real one is built from src/main.coffee to output dir
