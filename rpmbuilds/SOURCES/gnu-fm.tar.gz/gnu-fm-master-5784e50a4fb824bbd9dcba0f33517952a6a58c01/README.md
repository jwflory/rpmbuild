# GNU FM

A music community platform in PHP.

## License

License: Affero GPL version 3.0 or later.

## Main GNU FM developers:

*   [Michael Sheldon](http://blog.mikeasoft.com/) ([elleo](http://gitorious.org/~elleo))
*   Clint Adams ([clint](http://gitorious.org/~clint))
*   Jørgen Bøhnsdalen ([jurg](http://gitorious.org/~jurg))
*   [Matt Lee](http://matt.lee.name/) ([mattl](http://gitorious.org/~mattl))
*   Toby Inkster ([tobyink](http://gitorious.org/~tobyink))

### GNU FM wiki champion

*   Jonas Haraldsson ([kabniel](http://gitorious.org/~kabniel))

### All contributors

*   [Justin Baugh](http://deadmemes.net/) ([baughj](http://gitorious.org/~baughj))
*   Carlos Perilla (deepspawn)
*   [Donald R Robertson III](http://donaldrobertson.org/) (donald)
*   Evan Hanson (evhan)
*   Nicolas Reynolds (fauno)
*   Corey Farwell (frewsxcv)
*   Bernd Gruber (grubernd)
*   Marius Orcsik (habarnam)
*   David Mignot (idflood)
*   Jarkko Piiroinen (jarkko)
*   [John Sullivan](http://wjsullivan.net/) ([johnsu01](http://gitorious.org/~johnsu01))
*   [Joshua Gay](http://joshuagay.org/) (josh)
*   Mikael Nordfeldth (mmn)
*   Nikola Plejic (nikolaplejic)
*   Daniel Watkins (odd_bloke)
*   [Rob Myers](http://robmyers.org/) ([robmyers](http://gitorious.org/~robmyers))
*   Tony Biondo (tonyb486)
*   [Ward Vandewege](http://ward.vandewege.net/) ([cure](http://gitorious.org/~cure))
